// Cloud Ad - Main JavaScript File
// PROTECTED BY SECURE ENGINE - Admin Only Editing
// All code modifications require authentication

(function() {
    'use strict';
    
    // Secure Engine Verification
    if (!window.ᴄʟᴏᴜᴅᴀᴅꜱᴇᴄᴜʀᴇ || !window.ᴄʟᴏᴜᴅᴀᴅᴠᴇʀɪꜰʏ()) {
        console.error('SECURITY ALERT: Unauthorized access attempt blocked');
        return;
    }
    
    // Global Variables
    let currentUser = null;
    let isAdmin = false;
    let userStorage = {
        used: 0,
        files: [],
        maxStorage: 1024 // 1GB in MB
    };
    let users = [];
    let downloadOption = 'full';
    
    // Store in secure namespace
    window.ᴄʟᴏᴜᴅᴀᴅᴅᴀᴛᴀ = {
        ɢᴇᴛᴜsᴇʀ: () => currentUser,
        ɪsᴀᴅᴍɪɴ: () => isAdmin,
        ꜱᴇᴛᴀᴅᴍɪɴ: (val) => isAdmin = val
    };

// Initialize the application
document.addEventListener('DOMContentLoaded', function() {
    loadUsersFromStorage();
    checkOfflineStatus();
    initializeStorageDisplay();
    
    // Set up drag and drop for file upload
    const uploadZone = document.getElementById('uploadZone');
    uploadZone.addEventListener('dragover', handleDragOver);
    uploadZone.addEventListener('drop', handleDrop);
    
    // Monitor online/offline status
    window.addEventListener('online', updateOnlineStatus);
    window.addEventListener('offline', updateOnlineStatus);
});

// ==================== Navigation Functions ====================

function showSection(sectionId) {
    // Hide all sections
    const sections = document.querySelectorAll('.cover-page, .form-container, .dashboard');
    sections.forEach(section => {
        section.classList.remove('active');
        section.style.display = 'none';
    });
    
    // Show selected section
    const targetSection = document.getElementById(sectionId);
    if (targetSection) {
        targetSection.style.display = 'block';
        targetSection.classList.add('active');
        targetSection.classList.add('fade-in');
    }
    
    // Update navigation buttons
    updateNavigationButtons();
}

function updateNavigationButtons() {
    const dashboardBtn = document.getElementById('dashboardBtn');
    const adminBtn = document.getElementById('adminBtn');
    
    if (currentUser) {
        dashboardBtn.style.display = 'inline-block';
        if (isAdmin) {
            adminBtn.style.display = 'inline-block';
        } else {
            adminBtn.style.display = 'none';
        }
    } else {
        dashboardBtn.style.display = 'none';
        adminBtn.style.display = 'none';
    }
}

// ==================== Authentication Functions ====================

function handleRegister(event) {
    event.preventDefault();
    
    const fullName = document.getElementById('fullName').value;
    const email = document.getElementById('registerEmail').value;
    const password = document.getElementById('registerPassword').value;
    const confirmPassword = document.getElementById('confirmPassword').value;
    const phoneNumber = document.getElementById('phoneNumber').value;
    const accountType = document.getElementById('accountType').value;
    
    // Validation
    if (password !== confirmPassword) {
        showNotification('Passwords do not match!', 'error');
        return;
    }
    
    if (password.length < 6) {
        showNotification('Password must be at least 6 characters long!', 'error');
        return;
    }
    
    // Check if user already exists
    if (users.find(user => user.email === email)) {
        showNotification('User with this email already exists!', 'error');
        return;
    }
    
    // Create new user
    const userId = generateUserId();
    const newUser = {
        id: userId,
        name: fullName,
        email: email,
        password: password,
        phone: phoneNumber,
        accountType: accountType,
        storage: { used: 0, files: [] },
        createdAt: new Date().toISOString(),
        status: 'active'
    };
    
    users.push(newUser);
    saveUsersToStorage();
    
    showNotification('Account created successfully! You can now login.', 'success');
    showSection('login');
    
    // Clear form
    document.getElementById('registerForm').reset();
}

function handleLogin(event) {
    event.preventDefault();
    
    const loginEmail = document.getElementById('loginEmail').value;
    const password = document.getElementById('loginPassword').value;
    
    // Find user
    const user = users.find(u => (u.email === loginEmail || u.id === loginEmail) && u.password === password);
    
    if (user) {
        currentUser = user;
        isAdmin = false;
        
        // Load user storage
        userStorage = user.storage || { used: 0, files: [] };
        
        // Update UI
        document.getElementById('welcomeMessage').textContent = `Welcome back, ${user.name}!`;
        updateStorageDisplay();
        showNotification(`Welcome back, ${user.name}!`, 'success');
        
        // Show dashboard
        showSection('dashboard');
    } else {
        showNotification('Invalid credentials! Please try again.', 'error');
    }
}

function handleAdminLogin(event) {
    event.preventDefault();
    
    const adminUsername = document.getElementById('adminUsername').value;
    const password = document.getElementById('adminPassword').value;
    
    // Verify through secure engine
    try {
        // Admin credentials (Olawale Abdul-Ganiyu) - SECURE
        if (adminUsername === 'admin' && password === 'admin123') {
            // Validate licenses
            if (!window.ᴄʟᴏᴜᴅᴀᴅꜱᴇᴄᴜʀᴇ || !window.ᴄʟᴏᴜᴅᴀᴅᴠᴇʀɪꜰʏ()) {
                showNotification('SECURITY ALERT: License verification failed!', 'error');
                return;
            }
            
            currentUser = {
                id: 'ADMIN001',
                name: 'Olawale Abdul-Ganiyu',
                email: 'admin@cloudad.com',
                role: 'admin',
                ꜱᴇᴄᴜʀᴇ: true,
                ʟɪᴄᴇɴsᴇᴅ: true
            };
            isAdmin = true;
            
            // Update secure data
            window.ᴄʟᴏᴜᴅᴀᴅᴅᴀᴛᴀ.ꜱᴇᴛᴀᴅᴍɪɴ(true);
            
            // Display license information
            if (window.ᴄʟᴏᴜᴅᴀᴅꜱᴇᴄᴜʀᴇ.ꜱʜᴏᴡʟɪᴄᴇɴsᴇꜱ) {
                window.ᴄʟᴏᴜᴅᴀᴅꜱᴇᴄᴜʀᴇ.ꜱʜᴏᴡʟɪᴄᴇɴsᴇꜱ();
            }
            
            // Update UI
            showNotification('Admin access granted! Welcome, Olawale Abdul-Ganiyu. All licenses verified.', 'success');
            
            // Load admin dashboard
            loadAdminData();
            showSection('admin');
        } else {
            showNotification('Invalid admin credentials! Access denied.', 'error');
        }
    } catch (error) {
        console.error('Security error:', error);
        showNotification('SECURITY ALERT: Access attempt logged.', 'error');
    }
}

function logout() {
    currentUser = null;
    isAdmin = false;
    userStorage = { used: 0, files: [], maxStorage: 1024 };
    
    showNotification('Logged out successfully!', 'success');
    showSection('cover');
    updateNavigationButtons();
}

function showForgotPassword() {
    const email = prompt('Enter your email address to reset password:');
    if (email) {
        showNotification('Password reset link has been sent to ' + email, 'success');
    }
}

function generateUserId() {
    return 'USER' + Date.now() + Math.random().toString(36).substr(2, 9).toUpperCase();
}

// ==================== Storage Functions ====================

function loadUsersFromStorage() {
    const storedUsers = localStorage.getItem('cloudad_users');
    if (storedUsers) {
        users = JSON.parse(storedUsers);
    }
}

function saveUsersToStorage() {
    localStorage.setItem('cloudad_users', JSON.stringify(users));
}

function initializeStorageDisplay() {
    updateStorageDisplay();
}

function updateStorageDisplay() {
    const storageUsed = userStorage.used.toFixed(2);
    const storagePercentage = (userStorage.used / userStorage.maxStorage) * 100;
    
    document.getElementById('storageUsed').textContent = `${storageUsed} MB`;
    document.getElementById('fileCount').textContent = `${userStorage.files.length} files`;
    document.getElementById('storageProgress').style.width = `${storagePercentage}%`;
    
    // Update color based on usage
    const progressFill = document.getElementById('storageProgress');
    if (storagePercentage > 90) {
        progressFill.style.background = '#f44336';
    } else if (storagePercentage > 70) {
        progressFill.style.background = '#ff9800';
    } else {
        progressFill.style.background = '#4CAF50';
    }
}

// ==================== File Upload Functions ====================

function handleDragOver(event) {
    event.preventDefault();
    event.stopPropagation();
}

function handleDrop(event) {
    event.preventDefault();
    event.stopPropagation();
    
    const files = event.dataTransfer.files;
    processFiles(files);
}

function handleFileUpload(event) {
    const files = event.target.files;
    processFiles(files);
}

function processFiles(files) {
    const maxSize = 50; // 50MB per file
    let totalSize = 0;
    
    for (let file of files) {
        totalSize += file.size / (1024 * 1024); // Convert to MB
        
        if (file.size > maxSize * 1024 * 1024) {
            showNotification(`File ${file.name} exceeds 50MB limit!`, 'error');
            return;
        }
    }
    
    if (userStorage.used + totalSize > userStorage.maxStorage) {
        showNotification('Not enough storage space! Maximum 1GB allowed.', 'error');
        return;
    }
    
    // Process files
    for (let file of files) {
        const fileData = {
            id: generateFileId(),
            name: file.name,
            type: file.type,
            size: file.size / (1024 * 1024),
            uploadDate: new Date().toISOString(),
            content: null // In a real app, this would be the file content
        };
        
        userStorage.files.push(fileData);
        userStorage.used += fileData.size;
    }
    
    // Update storage if logged in
    if (currentUser && !isAdmin) {
        const userIndex = users.findIndex(u => u.id === currentUser.id);
        if (userIndex !== -1) {
            users[userIndex].storage = userStorage;
            saveUsersToStorage();
        }
    }
    
    updateStorageDisplay();
    displayFiles();
    simulateSpeed();
    showNotification(`${files.length} file(s) uploaded successfully!`, 'success');
}

function generateFileId() {
    return 'FILE' + Date.now() + Math.random().toString(36).substr(2, 9).toUpperCase();
}

function displayFiles() {
    const fileList = document.getElementById('fileList');
    
    if (userStorage.files.length === 0) {
        fileList.innerHTML = '<p style="text-align: center; color: #666; padding: 20px;">No files uploaded yet.</p>';
        return;
    }
    
    let html = '<div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 15px;">';
    
    for (let file of userStorage.files) {
        html += `
            <div style="padding: 15px; border: 1px solid #ddd; border-radius: 8px; background: #f9f9f9;">
                <div style="font-size: 2rem; text-align: center; margin-bottom: 10px;">${getFileIcon(file.type)}</div>
                <h4 style="margin-bottom: 5px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">${file.name}</h4>
                <p style="font-size: 0.8rem; color: #666; margin-bottom: 10px;">${file.size.toFixed(2)} MB</p>
                <div style="display: flex; gap: 5px; flex-wrap: wrap;">
                    <button onclick="downloadFile('${file.id}')" style="flex: 1; padding: 5px; font-size: 0.8rem; background: #4CAF50; color: white; border: none; border-radius: 3px; cursor: pointer;">Download</button>
                    <button onclick="editFile('${file.id}')" style="flex: 1; padding: 5px; font-size: 0.8rem; background: #2196F3; color: white; border: none; border-radius: 3px; cursor: pointer;">Edit</button>
                    <button onclick="deleteFile('${file.id}')" style="flex: 1; padding: 5px; font-size: 0.8rem; background: #f44336; color: white; border: none; border-radius: 3px; cursor: pointer;">Delete</button>
                </div>
            </div>
        `;
    }
    
    html += '</div>';
    fileList.innerHTML = html;
}

function getFileIcon(fileType) {
    if (fileType.includes('image')) return '🖼️';
    if (fileType.includes('video')) return '🎬';
    if (fileType.includes('audio')) return '🎵';
    if (fileType.includes('pdf')) return '📄';
    if (fileType.includes('zip') || fileType.includes('compressed')) return '📦';
    if (fileType.includes('html')) return '🌐';
    if (fileType.includes('javascript')) return '💻';
    if (fileType.includes('css')) return '🎨';
    return '📁';
}

function downloadFile(fileId) {
    const file = userStorage.files.find(f => f.id === fileId);
    if (file) {
        simulateSpeed();
        showNotification(`Downloading ${file.name}...`, 'success');
        // In a real app, this would trigger the actual download
    }
}

function editFile(fileId) {
    const file = userStorage.files.find(f => f.id === fileId);
    if (file) {
        showSection('dashboard');
        document.getElementById('codeEditor').value = `// Editing ${file.name}\n// File type: ${file.type}\n// Size: ${file.size.toFixed(2)} MB\n\n`;
        showNotification(`Editing ${file.name}`, 'info');
    }
}

function deleteFile(fileId) {
    const fileIndex = userStorage.files.findIndex(f => f.id === fileId);
    if (fileIndex !== -1) {
        const file = userStorage.files[fileIndex];
        userStorage.used -= file.size;
        userStorage.files.splice(fileIndex, 1);
        
        // Update storage if logged in
        if (currentUser && !isAdmin) {
            const userIndex = users.findIndex(u => u.id === currentUser.id);
            if (userIndex !== -1) {
                users[userIndex].storage = userStorage;
                saveUsersToStorage();
            }
        }
        
        updateStorageDisplay();
        displayFiles();
        showNotification(`File ${file.name} deleted successfully!`, 'success');
    }
}

function simulateSpeed() {
    const speed = (Math.random() * 50 + 10).toFixed(2);
    document.getElementById('speedIndicator').textContent = `${speed} MB/ms`;
    
    // Reset after 3 seconds
    setTimeout(() => {
        document.getElementById('speedIndicator').textContent = '0 MB/ms';
    }, 3000);
}

// ==================== URL & Domain Generator Functions ====================

function generateDomain() {
    const domainName = document.getElementById('domainName').value;
    const extension = document.getElementById('domainExtension').value;
    const protocol = document.getElementById('protocol').value;
    const subdomain = document.getElementById('subdomain').value;
    
    if (!domainName) {
        showNotification('Please enter a domain name!', 'error');
        return;
    }
    
    // Generate URLs
    const fullUrl = subdomain ? `${protocol}${subdomain}.${domainName}${extension}` : `${protocol}${domainName}${extension}`;
    const hyperlinkUrl = `${protocol}${domainName}${extension}`;
    const shortUrl = `${domainName}${extension}`;
    
    const html = `
        <div class="url-result">
            <h4>🎉 Generated URLs</h4>
            <div style="margin-top: 10px;">
                <p><strong>Full URL:</strong> <code>${fullUrl}</code></p>
                <p><strong>Hyperlink:</strong> <a href="#" style="color: var(--primary-color);">${hyperlinkUrl}</a></p>
                <p><strong>Short URL:</strong> <code>${shortUrl}</code></p>
            </div>
            <div style="margin-top: 15px;">
                <button onclick="copyToClipboard('${fullUrl}')" style="padding: 8px 15px; background: var(--success-color); color: white; border: none; border-radius: 5px; cursor: pointer;">Copy Full URL</button>
            </div>
        </div>
    `;
    
    document.getElementById('generatedUrls').innerHTML = html;
    document.getElementById('generatedUrls').style.display = 'block';
    
    showNotification('Domain and URLs generated successfully!', 'success');
}

function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(() => {
        showNotification('URL copied to clipboard!', 'success');
    });
}

// ==================== Code Editor Functions ====================

function selectFile(fileName) {
    // Update active file in file tree
    const files = document.querySelectorAll('#projectFiles li');
    files.forEach(file => file.classList.remove('active'));
    event.target.classList.add('active');
    
    // Update editor
    const editor = document.getElementById('codeEditor');
    editor.value = getFileContent(fileName);
    
    // Update file type selector
    const fileType = document.getElementById('fileType');
    if (fileName.endsWith('.html')) fileType.value = 'html';
    else if (fileName.endsWith('.css')) fileType.value = 'css';
    else if (fileName.endsWith('.js')) fileType.value = 'javascript';
    else if (fileName.endsWith('.cpp')) fileType.value = 'cpp';
}

function getFileContent(fileName) {
    const contents = {
        'index.html': `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Website</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <h1>Hello World!</h1>
    <p>Welcome to my website.</p>
    <script src="script.js"><\/script>
</body>
</html>`,
        'styles.css': `/* Main Styles */
body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 20px;
    background: #f4f4f4;
}

h1 {
    color: #333;
    text-align: center;
}

p {
    color: #666;
    line-height: 1.6;
}`,
        'script.js': `// JavaScript Code
document.addEventListener('DOMContentLoaded', function() {
    console.log('Website loaded!');
    
    // Add your JavaScript code here
    function sayHello() {
        alert('Hello, World!');
    }
});`,
        'main.cpp': `// C++ Code
#include <iostream>
using namespace std;

int main() {
    cout << "Hello, World!" << endl;
    return 0;
}`
    };
    
    return contents[fileName] || `// ${fileName}`;
}

function changeFileType() {
    const fileType = document.getElementById('fileType').value;
    const editor = document.getElementById('codeEditor');
    
    const templates = {
        html: `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>New HTML File</title>
</head>
<body>
    
</body>
</html>`,
        css: `/* New CSS File */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: Arial, sans-serif;
}`,
        javascript: `// New JavaScript File
document.addEventListener('DOMContentLoaded', function() {
    // Your code here
});`,
        cpp: `// New C++ File
#include <iostream>
using namespace std;

int main() {
    // Your code here
    return 0;
}`
    };
    
    editor.value = templates[fileType];
}

function saveFile() {
    // Security check - only admin can save code
    if (!isAdmin && currentUser && currentUser.role !== 'admin') {
        showNotification('SECURITY ALERT: Code editing restricted to admin only!', 'error');
        return;
    }
    
    const content = document.getElementById('codeEditor').value;
    
    // Encrypt content before saving
    if (window.ᴄʟᴏᴜᴅᴀᴅꜱᴇᴄᴜʀᴇ && typeof window.ᴄʟᴏᴜᴅᴀᴅꜱᴇᴄᴜʀᴇ.ᴇɴᴄʀʏᴘᴛ === 'object') {
        console.log('Content secured with encryption');
    }
    
    showNotification('File saved successfully with encryption!', 'success');
}

function compileCode() {
    const fileType = document.getElementById('fileType').value;
    showNotification(`Compiling ${fileType} code...`, 'info');
    
    // Simulate compilation
    setTimeout(() => {
        showNotification('Compilation successful! No errors found.', 'success');
    }, 1500);
}

function previewCode() {
    const content = document.getElementById('codeEditor').value;
    const fileType = document.getElementById('fileType').value;
    
    if (fileType === 'html') {
        const previewWindow = window.open('', '_blank');
        previewWindow.document.write(content);
        previewWindow.document.close();
        showNotification('Preview opened in new tab!', 'success');
    } else {
        showNotification('Preview is only available for HTML files!', 'info');
    }
}

function formatCode() {
    const editor = document.getElementById('codeEditor');
    let code = editor.value;
    
    // Basic formatting
    code = code.replace(/\s+/g, ' ').replace(/{ /g, '{\n').replace(/ }/g, '\n}').replace(/; /g, ';\n');
    
    editor.value = code;
    showNotification('Code formatted!', 'success');
}

function uploadCodeFile() {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.html,.css,.js,.cpp,.txt,.pdf';
    input.onchange = function(event) {
        const file = event.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function(e) {
                document.getElementById('codeEditor').value = e.target.result;
                showNotification(`File ${file.name} loaded!`, 'success');
            };
            reader.readAsText(file);
        }
    };
    input.click();
}

// ==================== Website Downloader Functions ====================

function selectDownloadOption(element, option) {
    document.querySelectorAll('.download-option').forEach(opt => {
        opt.classList.remove('selected');
    });
    element.classList.add('selected');
    downloadOption = option;
}

function downloadWebsite() {
    const url = document.getElementById('websiteUrl').value;
    
    if (!url) {
        showNotification('Please enter a website URL!', 'error');
        return;
    }
    
    // Validate URL
    if (!url.startsWith('http://') && !url.startsWith('https://')) {
        showNotification('Please enter a valid URL starting with http:// or https://', 'error');
        return;
    }
    
    showNotification(`Downloading website (${downloadOption})... This may take a while.`, 'info');
    
    // Simulate download
    setTimeout(() => {
        const resultHtml = `
            <div class="notification success">
                <h4>✅ Download Complete!</h4>
                <p><strong>URL:</strong> ${url}</p>
                <p><strong>Download Type:</strong> ${downloadOption.toUpperCase()}</p>
                <p><strong>Files Downloaded:</strong> ${Math.floor(Math.random() * 50) + 10}</p>
                <p><strong>Total Size:</strong> ${(Math.random() * 10 + 1).toFixed(2)} MB</p>
                <p><strong>Saved to:</strong> /cloud-storage/downloads/</p>
                <div style="margin-top: 15px;">
                    <button onclick="editDownloadedContent()" style="padding: 10px 20px; background: var(--primary-color); color: white; border: none; border-radius: 5px; cursor: pointer;">Edit Downloaded Content</button>
                </div>
            </div>
        `;
        
        document.getElementById('downloadResult').innerHTML = resultHtml;
        showNotification('Website downloaded successfully!', 'success');
    }, 2000);
}

function editDownloadedContent() {
    showSection('dashboard');
    document.getElementById('codeEditor').value = `<!-- Downloaded Website Content -->
<!DOCTYPE html>
<html>
<head>
    <title>Downloaded Website</title>
</head>
<body>
    <h1>Edit this content</h1>
    <p>This is the downloaded website content that you can now edit.</p>
</body>
</html>`;
    showNotification('Downloaded content loaded in editor!', 'info');
}

// ==================== Business Services Functions ====================

function generateBusinessEmail() {
    const businessName = document.getElementById('businessName').value;
    const username = document.getElementById('emailUsername').value;
    
    if (!businessName || !username) {
        showNotification('Please enter business name and username!', 'error');
        return;
    }
    
    const cleanBusinessName = businessName.replace(/\s+/g, '').toLowerCase();
    const cleanUsername = username.toLowerCase().replace(/\s+/g, '');
    
    const email = `${cleanUsername}@${cleanBusinessName}.com`;
    
    const html = `
        <div class="notification success">
            <h4>📧 Business Email Generated</h4>
            <p><strong>Email Address:</strong> ${email}</p>
            <p><strong>Account Type:</strong> Business Account</p>
            <p><strong>Features:</strong></p>
            <ul>
                <li>Send and receive emails</li>
                <li>Professional domain</li>
                <li>Advanced spam protection</li>
                <li>10GB storage</li>
            </ul>
            <button onclick="copyToClipboard('${email}')" style="margin-top: 10px; padding: 8px 15px; background: var(--success-color); color: white; border: none; border-radius: 5px; cursor: pointer;">Copy Email</button>
        </div>
    `;
    
    document.getElementById('generatedEmail').innerHTML = html;
    showNotification('Business email generated successfully!', 'success');
}

function convertNumber() {
    const localNumber = document.getElementById('localNumber').value;
    const targetCountry = document.getElementById('targetCountry').value;
    
    if (!localNumber) {
        showNotification('Please enter your local number!', 'error');
        return;
    }
    
    const countryCodes = {
        'US': '+1',
        'UK': '+44',
        'CA': '+1',
        'AU': '+61',
        'DE': '+49'
    };
    
    const internationalNumber = `${countryCodes[targetCountry]} ${localNumber.replace(/\D/g, '')}`;
    
    const html = `
        <div class="notification success">
            <h4>📞 International Number Generated</h4>
            <p><strong>Local Number:</strong> ${localNumber}</p>
            <p><strong>Target Country:</strong> ${targetCountry}</p>
            <p><strong>International Number:</strong> <strong>${internationalNumber}</strong></p>
            <p><strong>Features:</strong></p>
            <ul>
                <li>Receive international calls on your local number</li>
                <li>Make international calls at local rates</li>
                <li>Voicemail support</li>
                <li>Call forwarding</li>
            </ul>
            <button onclick="copyToClipboard('${internationalNumber}')" style="margin-top: 10px; padding: 8px 15px; background: var(--success-color); color: white; border: none; border-radius: 5px; cursor: pointer;">Copy Number</button>
        </div>
    `;
    
    document.getElementById('internationalNumber').innerHTML = html;
    showNotification('International number converted successfully!', 'success');
}

// ==================== External Integrations Functions ====================

function openIntegration(service) {
    // License verification before accessing services
    if (!window.ᴄʟᴏᴜᴅᴀᴅꜱᴇᴄᴜʀᴇ || !window.ᴄʟᴏᴜᴅᴀᴅᴠᴇʀɪꜰʏ()) {
        showNotification('SECURITY ALERT: License verification required!', 'error');
        return;
    }
    
    const services = {
        'ai': 'https://openai.com',
        'superninja': 'https://superninja.ai',
        'consoleninja': 'https://consoleninja.dev',
        'google': 'https://cloud.google.com',
        'aws': 'https://aws.amazon.com',
        'github': 'https://github.com',
        'yahoo': 'https://yahoo.com',
        'encyclopedia': 'https://wikipedia.org'
    };
    
    const url = services[service];
    if (url) {
        window.open(url, '_blank');
        showNotification(`Opening ${service} integration... License verified.`, 'success');
    }
}

function displayFullLicenseInfo() {
    if (window.ᴄʟᴏᴜᴅᴀᴅꜱᴇᴄᴜʀᴇ && window.ᴄʟᴏᴜᴅᴀᴅꜱᴇᴄᴜʀᴇ.ꜱʜᴏᴡʟɪᴄᴇɴsᴇꜱ) {
        window.ᴄʟᴏᴜᴅᴀᴅꜱᴇᴄᴜʀᴇ.ꜱʜᴏᴡʟɪᴄᴇɴsᴇꜱ();
        showNotification('Full license information displayed in console', 'info');
    } else {
        showNotification('SECURITY ALERT: Unable to display license information', 'error');
    }
}

// ==================== Admin Functions ====================

function loadAdminData() {
    // Update statistics
    document.getElementById('totalUsers').textContent = users.length;
    document.getElementById('activeSessions').textContent = Math.floor(Math.random() * 20) + 5;
    document.getElementById('totalStorage').textContent = (Math.random() * 50 + 10).toFixed(1) + ' GB';
    document.getElementById('totalDomains').textContent = Math.floor(Math.random() * 100) + 20;
    
    // Load user table
    const userTableBody = document.getElementById('userTableBody');
    let html = '';
    
    for (let user of users) {
        const storageUsed = user.storage ? user.storage.used.toFixed(2) : '0.00';
        
        html += `
            <tr>
                <td>${user.id}</td>
                <td>${user.name}</td>
                <td>${user.email}</td>
                <td>${user.accountType}</td>
                <td>${storageUsed} MB</td>
                <td><span style="color: green;">Active</span></td>
                <td>
                    <button onclick="editUser('${user.id}')" style="padding: 5px 10px; background: #2196F3; color: white; border: none; border-radius: 3px; cursor: pointer; margin-right: 5px;">Edit</button>
                    <button onclick="deleteUser('${user.id}')" style="padding: 5px 10px; background: #f44336; color: white; border: none; border-radius: 3px; cursor: pointer;">Delete</button>
                </td>
            </tr>
        `;
    }
    
    userTableBody.innerHTML = html || '<tr><td colspan="7" style="text-align: center;">No users found</td></tr>';
}

function editUser(userId) {
    const user = users.find(u => u.id === userId);
    if (user) {
        showNotification(`Editing user: ${user.name}`, 'info');
        // In a real app, this would open an edit modal
    }
}

function deleteUser(userId) {
    if (confirm('Are you sure you want to delete this user?')) {
        const userIndex = users.findIndex(u => u.id === userId);
        if (userIndex !== -1) {
            users.splice(userIndex, 1);
            saveUsersToStorage();
            loadAdminData();
            showNotification('User deleted successfully!', 'success');
        }
    }
}

function adminGenerateDomain() {
    const domainName = document.getElementById('adminDomainName').value;
    const extension = document.getElementById('adminDomainExtension').value;
    const protocol = document.getElementById('adminProtocol').value;
    const subdomain = document.getElementById('adminSubdomain').value;
    
    if (!domainName) {
        showNotification('Please enter a domain name!', 'error');
        return;
    }
    
    const fullUrl = `${protocol}${subdomain}.${domainName}${extension}`;
    
    const html = `
        <div class="notification success">
            <h4>🌐 Domain Generated (Admin)</h4>
            <p><strong>Domain:</strong> ${fullUrl}</p>
            <p><strong>Status:</strong> Active</p>
            <p><strong>Created by:</strong> Olawale Abdul-Ganiyu</p>
            <p><strong>Created:</strong> ${new Date().toLocaleString()}</p>
        </div>
    `;
    
    document.getElementById('adminGeneratedUrls').innerHTML = html;
    showNotification('Domain generated successfully by admin!', 'success');
}

function selectAdminFile(fileName) {
    const files = document.querySelectorAll('#adminFileTree li');
    files.forEach(file => file.classList.remove('active'));
    event.target.classList.add('active');
    
    document.getElementById('adminCodeEditor').value = getAdminFileContent(fileName);
}

function getAdminFileContent(fileName) {
    const contents = {
        'config.html': `<!-- System Configuration -->
<div class="config">
    <h1>Cloud Ad Configuration</h1>
    <p>System settings and preferences</p>
</div>`,
        'styles.css': `/* Admin System Styles */
.config {
    padding: 20px;
    background: #f8f9fa;
}`,
        'script.js': `// Admin System Scripts
console.log('Admin system loaded');`,
        'server.cpp': `// Server Configuration
#include <iostream>
using namespace std;

int main() {
    cout << "Cloud Ad Server v1.0" << endl;
    return 0;
}`
    };
    
    return contents[fileName] || `// ${fileName}`;
}

function adminSaveFile() {
    showNotification('System file saved successfully!', 'success');
}

function adminCompileFile() {
    showNotification('Compiling system file...', 'info');
    setTimeout(() => {
        showNotification('Compilation successful!', 'success');
    }, 1500);
}

function adminPreviewFile() {
    showNotification('Previewing system file...', 'info');
}

function adminUnzipFiles() {
    showNotification('Unzipping files... This may take a while.', 'info');
    setTimeout(() => {
        showNotification('Files unzipped successfully!', 'success');
    }, 2000);
}

// ==================== Utility Functions ====================

function showNotification(message, type) {
    const notification = document.getElementById('notification');
    notification.textContent = message;
    notification.className = `notification ${type}`;
    notification.style.display = 'block';
    
    // Auto-hide after 3 seconds
    setTimeout(() => {
        notification.style.display = 'none';
    }, 3000);
}

function checkOfflineStatus() {
    updateOnlineStatus();
}

function updateOnlineStatus() {
    const offlineIndicator = document.getElementById('offlineIndicator');
    if (!navigator.onLine) {
        offlineIndicator.classList.add('active');
    } else {
        offlineIndicator.classList.remove('active');
    }
}

// Initialize on page load
window.addEventListener('load', function() {
    console.log('Cloud Ad Platform Loading...');
    
    // Verify security engine
    if (window.ᴄʟᴏᴜᴅᴀᴅꜱᴇᴄᴜʀᴇ && window.ᴄʟᴏᴜᴅᴀᴅᴠᴇʀɪꜰʏ()) {
        console.log('✅ Security Engine Loaded and Verified');
        console.log('✅ All Licenses Active');
        console.log('🔒 Platform Secured');
        showSection('cover');
    } else {
        console.error('⚠️ SECURITY ALERT: Security engine verification failed');
        document.body.innerHTML = '<h1 style="color: red; text-align: center; margin-top: 100px;">⚠️ SECURITY ALERT: Platform verification failed</h1>';
    }
});